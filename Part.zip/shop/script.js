const products = [
    {
        name: "لپ‌تاپ",
        price: 180000000,
        image: "images/laptop.webp"
    },
    {
        name: "موبایل",
        price: 150000000,
        image: "images/mobile.webp"
    },
    {
        name: "هدفون",
        price: 4000000,
        image: "images/headphone.webp"
    }
];

// تست
// console.log(products);
// console.log(products[1].price);

const title = document.querySelector("#title");
title.textContent = "TechShop";

const productList = document.querySelector(".product-list");
products.forEach(function (product) {
    productList.innerHTML += `
        <article class="product-card">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <h3>${product.name}</h3>
            <p>قیمت: ${product.price.toLocaleString("fa-IR")} تومان</p>
            <button class="add-to-cart">افزودن به سبد خرید</button>
        </article>
    `;
});



let cart = [];
cart = JSON.parse(localStorage.getItem("cart")) || [];
const cartCount = document.querySelector("#cart-count");
const cartTotal = document.querySelector("#cart-total");
const cartItems = document.querySelector("#cart-items");



const buttons = document.querySelectorAll(".add-to-cart");

function renderCart() {
    cartItems.innerHTML = "";

    cart.forEach(function (item, index) {
        cartItems.innerHTML += `
            <li>
                ${item.name} - ${item.price.toLocaleString("fa-IR")} تومان
                <button class="remove-item" data-index="${index}">
                    حذف
                </button>
            </li>
        `;
    });

    cartCount.textContent = cart.length;

    const total = cart.reduce(function (sum, item) {
        return sum + item.price;
    }, 0);

    cartTotal.textContent = total.toLocaleString("fa-IR");
    localStorage.setItem("cart", JSON.stringify(cart));
}

buttons.forEach(function (button, index) {
    button.addEventListener("click", function () {
        cart.push(products[index]);
        renderCart();
    });
});

cartItems.addEventListener("click", function (event) {
    if (event.target.classList.contains("remove-item")) {
        const index = Number(event.target.dataset.index);
        cart.splice(index, 1);
        renderCart();
    }
});

renderCart();
